const express=require("express")
const app=express()

app.get("/", async(req,response)=>{
    try {
const urls=req.query.url
Promise.all(urls.map(list => 
    fetch(list).then(resp => resp.json())
  ))
  .then((data)=>{
    let numbers=[];
    data.map((item)=>{
        numbers = numbers.concat(item.numbers);
    })
    
   return response.status(200).json({"numbers":numbers})
  }).catch(error => {
    return response.status(402).json({err:"External Server Error..."})
  });
   
} catch (err) {
	return response.status(401).json({err:err.message})
}

})
app.listen(8080,()=>{
    console.log("server running")
})