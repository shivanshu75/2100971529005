import { useEffect, useState } from "react";
import Train from "./Train";
import Login from "./Login";

function Home() {
    const [data,setData]=useState([]);
  const [token,setToken]=useState("")


  
    const getToken = () => {
        const tokenString = localStorage.getItem('token');
        const userToken = JSON.parse(tokenString);
        console.log(userToken)
        setToken(userToken)
      };


  
  useEffect(()=>{
    getToken();
    

  },[])
  
  useEffect(()=>{
    getData();
  },[token])
  

  
   const getData=async ()=>{
    fetch("http://20.244.56.144/train/trains", { 
      method: 'get', 
      headers: {
        'Content-type': 'application/json',
        'Authorization': `Bearer ${token}`, // notice the Bearer before your token
    },
  })
    .then(response => response.json())
    .then(result => {
      console.log(result)

      setData(result)
    })
    .catch(error => console.log('error', error));
  }
  

  return (
  
    <>

    
     <div className="container" style={{ padding: 10 }}>
     <div className="container-fluid">
    <div className="row">
      <div className="col-sm-12" style={{ backgroundColor: "aqua" }}>
        <h1 style={{ textAlign: "center", padding: 20 }}>Train List</h1>
      </div>
    </div>
  </div>

  

     {data.length>0?data.map((item,index)=><Train key={index} item={item}/>):<Login/>}
     </div>
  
</>


  )
}

export default Home
