
const saveToken = userToken => {
    localStorage.setItem('token', JSON.stringify(userToken));
  };

export default function Login() {
    

    async function loginUser() {
        return fetch('http://20.244.56.144/train/auth', {
          method: 'POST',
          body: JSON.stringify({
            "companyName": "Shivanshu Travels",
            "clientID": "bd548d14-aee2-4cfd-860d-198806d710d7",
            "clientSecret": "FwbQbXWUYhqFXRPw",
            "ownerName": "Shivanshu",
            "ownerEmail": "shivanshu@gmail.com",
            "rollNo": "2100971529005"
        })
        })
          .then(data => data.json())
       }

       const handleSubmit = async e => {
        e.preventDefault();
        const token = await loginUser();
        saveToken(token.access_token);
        
      }

      
  return(
    <form onSubmit={handleSubmit}>
      {/* <label>
        <p>Username</p>
        <input type="text" onChange={e => setUserName(e.target.value)}/>
      </label>
      <label>
        <p>Password</p>
        <input type="password" onChange={e => setPassword(e.target.value)}/>
      </label> */}
      <div>
        <button type="submit">Login</button>
<br></br>
        Refresh after Login
      </div>
    </form>
  )
}

