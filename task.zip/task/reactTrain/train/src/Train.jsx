const Train=({item})=>{
    return(<div className=" row  mt-5">
     <div className="col-sm-12">
      <div className="card">
        <div className="card-header">{item.trainName}-{item.trainNumber}</div>
        <div className="card-body">
        <p className="card-text">
            Delay-{item.delayedBy} Min
          </p>
          <p className="card-text">
          Time - {item.departureTime.Hours}H-{item.departureTime.Minutes}M-{item.departureTime.Seconds}S
          </p>
          <h4 className="card-title">AC</h4>

          <p className="card-text">
          Seat -{item.seatsAvailable.AC}
          </p>

          <p className="card-text">
          Price - {item.price.AC}
          </p>
          <h4 className="card-title">Sleeper</h4>

<p className="card-text">
Seat -{item.seatsAvailable.sleeper}
</p>

<p className="card-text">
Price - {item.price.sleeper}
</p>

          
        
        </div>
      </div>
    </div>
   
    </div>)

}
export default Train;